import * as React from 'react';
import {View, Text} from 'react-native';

export default class WriteStory extends React.Component{
  render(){
    return (
      <Text>
        WriteStory
      </Text>
    )
  }
}